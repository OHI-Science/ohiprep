var regions = {"type":"FeatureCollection","features":[
  {"type":"Feature",
   "properties":{"region_id":1, "region_name":"Australian Alps"},
   "geometry":{"type":"Polygon","coordinates":[[[141.13037109375,-38.788345355085625],[141.13037109375,-36.65079252503469],[144.38232421875,-36.65079252503469],[144.38232421875,-38.788345355085625],[141.13037109375,-38.788345355085625]]]}},
  {"type":"Feature",
   "properties":{"region_id":4, "region_name":"Shark Bay"},
   "geometry":{"type":"Polygon","coordinates":[[[143.10791015625,-37.75334401310656],[143.10791015625,-34.95799531086791],[146.25,-34.95799531086791],[146.25,-37.75334401310656],[143.10791015625,-37.75334401310656]]]}}
  ]}