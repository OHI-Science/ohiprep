ohi-global
==========

Global scenarios of the Ocean Health Index 

The [calculate.R](./calculate.R) script generates the final global2014/scores.csv. The following sequence of calculating each scenario is needed:

1. **global2013**
1. **global2012** must follow global2013 in order to load global2013/scores.csv for LE Eritrea issue